//>>built
define("dijit/form/nls/hu/validate",({invalidMessage:"A megadott érték érvénytelen.",missingMessage:"Meg kell adni egy értéket.",rangeMessage:"Az érték kívül van a megengedett tartományon."}));
