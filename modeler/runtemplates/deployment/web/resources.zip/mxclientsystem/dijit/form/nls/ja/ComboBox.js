//>>built
define("dijit/form/nls/ja/ComboBox",{previousMessage:"\u4ee5\u524d\u306e\u9078\u629e\u9805\u76ee",nextMessage:"\u8ffd\u52a0\u306e\u9078\u629e\u9805\u76ee"});
