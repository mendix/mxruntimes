//>>built
define("dijit/_editor/nls/zh/LinkDialog",{createLinkTitle:"\u94fe\u63a5\u5c5e\u6027",insertImageTitle:"\u56fe\u50cf\u5c5e\u6027",url:"URL\uff1a",text:"\u8bf4\u660e\uff1a",target:"\u76ee\u6807\uff1a",set:"\u96c6",currentWindow:"\u5f53\u524d\u7a97\u53e3",parentWindow:"\u7236\u7a97\u53e3",topWindow:"\u6700\u9876\u5c42\u7a97\u53e3",newWindow:"\u65b0\u5efa\u7a97\u53e3"});
