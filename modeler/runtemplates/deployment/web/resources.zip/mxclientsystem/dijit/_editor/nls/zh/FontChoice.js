//>>built
define("dijit/_editor/nls/zh/FontChoice",{fontSize:"\u5927\u5c0f",fontName:"\u5b57\u4f53",formatBlock:"\u683c\u5f0f",serif:"\u6709\u886c\u7ebf","sans-serif":"\u65e0\u886c\u7ebf",monospace:"\u7b49\u5bbd\u5b57\u4f53",cursive:"\u8349\u4e66",fantasy:"\u865a\u7ebf",noFormat:"\u65e0",p:"\u6bb5\u843d",h1:"\u6807\u9898",h2:"\u526f\u6807\u9898",h3:"\u4e8c\u7ea7\u5b50\u6807\u9898",pre:"\u9884\u8bbe\u6709\u683c\u5f0f\u7684",1:"XX \u5c0f\u53f7",2:"X \u5c0f\u53f7",3:"\u5c0f\u53f7",4:"\u4e2d\u53f7",5:"\u5927\u53f7",
6:"X \u5927\u53f7",7:"XX \u5927\u53f7"});
