//>>built
define("dijit/_editor/nls/da/LinkDialog",{createLinkTitle:"Linkegenskaber",insertImageTitle:"Billedegenskaber",url:"URL:",text:"Beskrivelse:",target:"M\u00e5l:",set:"Defin\u00e9r",currentWindow:"Aktuelt vindue",parentWindow:"Overordnet vindue",topWindow:"\u00d8verste vindue",newWindow:"Nyt vindue"});
