//>>built
define("dijit/_editor/nls/nb/LinkDialog",{createLinkTitle:"Koblingsegenskaper",insertImageTitle:"Bildeegenskaper",url:"URL:",text:"Beskrivelse:",target:"M\u00e5l:",set:"Definer",currentWindow:"Gjeldende vindu",parentWindow:"Overordnet vindu",topWindow:"\u00d8verste vindu",newWindow:"Nytt vindu"});
