//>>built
define("dijit/_editor/nls/sk/LinkDialog",{createLinkTitle:"Vlastnosti prepojenia",insertImageTitle:"Vlastnosti obr\u00e1zka",url:"Adresa URL:",text:"Opis:",target:"Cie\u013e:",set:"Nastavi\u0165",currentWindow:"Aktu\u00e1lne okno",parentWindow:"Rodi\u010dovsk\u00e9 okno",topWindow:"Najvy\u0161\u0161ie okno",newWindow:"Nov\u00e9 okno"});
