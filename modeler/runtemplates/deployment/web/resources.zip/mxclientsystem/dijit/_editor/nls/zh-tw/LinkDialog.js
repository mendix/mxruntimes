//>>built
define("dijit/_editor/nls/zh-tw/LinkDialog",{createLinkTitle:"\u93c8\u7d50\u5167\u5bb9",insertImageTitle:"\u5f71\u50cf\u5167\u5bb9",url:"URL\uff1a",text:"\u8aaa\u660e\uff1a",target:"\u76ee\u6a19\uff1a",set:"\u8a2d\u5b9a",currentWindow:"\u73fe\u884c\u8996\u7a97",parentWindow:"\u4e0a\u5c64\u8996\u7a97",topWindow:"\u6700\u4e0a\u9762\u7684\u8996\u7a97",newWindow:"\u65b0\u8996\u7a97"});
