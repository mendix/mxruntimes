//>>built
define("dijit/nls/bs/loading",{loadingState:"U\u010ditavanje...",errorState:"Izvinite, do\u0161lo je do gre\u0161ke"});
