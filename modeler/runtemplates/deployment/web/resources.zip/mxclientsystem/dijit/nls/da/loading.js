//>>built
define("dijit/nls/da/loading",{loadingState:"Indl\u00e6ser...",errorState:"Der er opst\u00e5et en fejl"});
