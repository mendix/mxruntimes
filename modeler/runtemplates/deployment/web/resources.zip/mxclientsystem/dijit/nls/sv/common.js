//>>built
define("dijit/nls/sv/common",{buttonOk:"OK",buttonCancel:"Avbryt",buttonSave:"Spara",itemClose:"St\u00e4ng"});
