//>>built
define("dijit/nls/pl/common",{buttonOk:"OK",buttonCancel:"Anuluj",buttonSave:"Zapisz",itemClose:"Zamknij"});
