//>>built
define("dijit/_OnDijitClickMixin","dojo/on dojo/_base/array dojo/keys dojo/_base/declare dojo/has ./a11yclick".split(" "),function(a,e,f,b,g,c){a=b("dijit._OnDijitClickMixin",null,{connect:function(a,d,b){return this.inherited(arguments,[a,"ondijitclick"==d?c:d,b])}});a.a11yclick=c;return a});
