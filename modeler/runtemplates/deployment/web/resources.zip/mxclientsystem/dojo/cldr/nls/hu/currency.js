/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/hu/currency",{HKD_displayName:"hongkongi doll\u00e1r",CHF_displayName:"sv\u00e1jci frank",JPY_symbol:"\u00a5",CAD_displayName:"kanadai doll\u00e1r",HKD_symbol:"HKD",CNY_displayName:"K\u00ednai j\u00fcan renminbi",USD_symbol:"$",AUD_displayName:"ausztr\u00e1l doll\u00e1r",JPY_displayName:"jap\u00e1n jen",CAD_symbol:"CAD",USD_displayName:"USA-doll\u00e1r",EUR_symbol:"EUR",CNY_symbol:"CNY",GBP_displayName:"brit font sterling",GBP_symbol:"GBP",AUD_symbol:"AUD",EUR_displayName:"eur\u00f3"});
