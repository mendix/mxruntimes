/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/cs/currency",{HKD_displayName:"hongkongsk\u00fd dolar",CHF_displayName:"\u0161v\u00fdcarsk\u00fd frank",JPY_symbol:"JP\u00a5",CAD_displayName:"kanadsk\u00fd dolar",HKD_symbol:"HK$",CNY_displayName:"\u010d\u00ednsk\u00fd j\u00fcan",USD_symbol:"US$",AUD_displayName:"australsk\u00fd dolar",JPY_displayName:"japonsk\u00fd jen",CAD_symbol:"CA$",USD_displayName:"americk\u00fd dolar",EUR_symbol:"\u20ac",CNY_symbol:"CN\u00a5",GBP_displayName:"britsk\u00e1 libra",GBP_symbol:"\u00a3",AUD_symbol:"AU$",
EUR_displayName:"euro"});
