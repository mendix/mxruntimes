/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/pt-pt/roc",{"field-sat-relative+0":"este s\u00e1bado","field-sat-relative+1":"pr\u00f3ximo s\u00e1bado","field-dayperiod":"Da manh\u00e3/da tarde","field-sun-relative+-1":"domingo passado","field-mon-relative+-1":"segunda-feira passada","field-minute":"Minuto","field-day-relative+-1":"ontem","field-weekday":"Dia da semana","field-day-relative+-2":"anteontem","field-era":"Era","field-hour":"Hora","field-sun-relative+0":"este domingo","field-sun-relative+1":"pr\u00f3ximo domingo",
"field-wed-relative+-1":"quarta-feira passada","field-day-relative+0":"hoje","field-day-relative+1":"amanh\u00e3","field-day-relative+2":"depois de amanh\u00e3","field-tue-relative+0":"esta ter\u00e7a-feira","field-zone":"Fuso hor\u00e1rio","field-tue-relative+1":"pr\u00f3xima ter\u00e7a-feira","field-week-relative+-1":"semana passada","field-year-relative+0":"este ano","field-year-relative+1":"pr\u00f3ximo ano","field-sat-relative+-1":"s\u00e1bado passado","field-year-relative+-1":"ano passado",
"field-year":"Ano","field-fri-relative+0":"esta sexta-feira","field-fri-relative+1":"pr\u00f3xima sexta-feira","field-week":"Semana","field-week-relative+0":"esta semana","field-week-relative+1":"pr\u00f3xima semana","field-month-relative+0":"este m\u00eas","field-month":"M\u00eas","field-month-relative+1":"pr\u00f3ximo m\u00eas","field-fri-relative+-1":"sexta-feira passada","field-second":"Segundo","field-tue-relative+-1":"ter\u00e7a-feira passada","field-day":"Dia","field-mon-relative+0":"esta segunda-feira",
"field-mon-relative+1":"pr\u00f3xima segunda-feira","field-thu-relative+0":"esta quinta-feira","dateFormat-short":"d/M/y G","field-thu-relative+1":"pr\u00f3xima quinta-feira","field-wed-relative+0":"esta quarta-feira","field-wed-relative+1":"pr\u00f3xima quarta-feira","field-month-relative+-1":"m\u00eas passado","field-thu-relative+-1":"quinta-feira passada"});
