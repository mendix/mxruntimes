/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/fi/currency",{"HKD_displayName":"Hongkongin dollari","CHF_displayName":"Sveitsin frangi","JPY_symbol":"¥","CAD_displayName":"Kanadan dollari","HKD_symbol":"HKD","CNY_displayName":"Kiinan yuan","USD_symbol":"$","AUD_displayName":"Australian dollari","JPY_displayName":"Japanin jeni","CAD_symbol":"CAD","USD_displayName":"Yhdysvaltain dollari","EUR_symbol":"€","CNY_symbol":"CNY","GBP_displayName":"Englannin punta","GBP_symbol":"£","AUD_symbol":"AUD","EUR_displayName":"euro"});
