/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/require",["./_base/loader"],function(a){return{dynamic:0,normalize:function(a){return a},load:a.require}});
