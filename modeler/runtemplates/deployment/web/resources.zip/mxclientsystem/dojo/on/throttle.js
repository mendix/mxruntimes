/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/on/throttle",["../throttle","../on"],function(a,b){return function(c,d){return function(e,f){return b(e,c,a(f,d))}}});
